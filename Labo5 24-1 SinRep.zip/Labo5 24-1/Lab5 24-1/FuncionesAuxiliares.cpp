/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

/* 
 * Archivo:   FuncionesAuxiliares.cpp
 * Autor: VinKzzlo
 *
 * Creado el on 12 de mayo de 2024, 21:47
 */

#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;
#include "FuncionesAuxiliares.h"
#define NO_ENCONTRADO -1
#define TAMLINEA 111

void leeDatosMedicos(const char *nombArch,int *medicosCods,double *medicosTarifa,
                     int &numMedicos){
    ifstream arch(nombArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    int codigo;
    double tarifa;
    
    numMedicos=0;
    while(true){
        arch>>codigo;
        if(arch.eof()) break;
        arch>>ws;
        arch.get(); //Leo el primer '/'
        while(arch.get() != '/');
        arch>>ws;
        while(arch.get() != ' ');
        arch>>tarifa;
        medicosCods[numMedicos] = codigo;
        medicosTarifa[numMedicos] = tarifa;
        numMedicos++;
    }
}

void leeDatosMedicinas(const char *nombArch,int *medicinCods,
                       double *medicinPrecios, int &numMedicin){
    ifstream arch(nombArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    int codigo;
    double precio;
    
    numMedicin=0;
    while(true){
        arch>>codigo;
        if(arch.eof()) break;
        arch>>ws;
        while(arch.get() != ' ');
        arch>>precio;
        medicinCods[numMedicin] = codigo;
        medicinPrecios[numMedicin] = precio;
        numMedicin++;
    }
}

void reporteDePrueba(const char *nombArch,int *medicosCods,double *medicosTarifa,
                     int numMedicos,
                    int *medicinCods,double *medicinPrecios,int numMedicin){
    ofstream arch(nombArch,ios::out);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    arch.precision(2);
    arch<<fixed;
    
    arch<<"Archivo de Medicos"<<endl;
    arch<<setw(25)<<"Codigo del Medico"<<setw(15)<<"Tarifa"<<endl;
    for(int i=0; i<numMedicos;i++){
        arch<<setw(25)<<medicosCods[i]<<setw(15)<<medicosTarifa[i]<<endl;
    }
        
    arch<<endl<<endl;
    arch<<"Archivo de Medicinas"<<endl;
    arch<<setw(25)<<"Codigo de la Medicina"<<setw(15)<<"Precio"<<endl;
    for(int i=0; i<numMedicin;i++){
        arch<<setw(25)<<medicinCods[i]<<setw(15)<<medicinPrecios[i]<<endl;
    }
        
    
}
void actualizarTotales(const char *nombArch,int *medicosCods,double *medicosTarifa,
                      int *medicosPacRec,int *medicosPacNoRec,double *medicosIngCitas,
                      double *medicosIngMeds,int numMedicos,
                      int *medicinCods,double *medicinPrecios,int *medicinCantVend,
                      double *medicinIngSinD,double *medicinDctos,int numMedicin){
    ifstream arch(nombArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    int dd,mm,aa,DNIPac,codMedico,horaI,horaF, duracionEnH;
    int posMedico;
    double porcDcto;
    char c;
    while(true){
        arch>>dd;
        if(arch.eof()) break;
        arch>>c>>mm>>c>>aa>>DNIPac>>porcDcto;
        horaI = leerObtenerHora(arch);
        horaF = leerObtenerHora(arch);
        duracionEnH = (horaF-horaI)/(double)3600;
        arch>>codMedico;
        posMedico = buscarPosicionMedico(codMedico,medicosCods,numMedicos);
        if(posMedico != NO_ENCONTRADO){
            actualizarIngresoCita(medicosIngCitas[posMedico],duracionEnH,
                                  medicosTarifa[posMedico],porcDcto);
            if(arch.get() != '\n'){
                medicosPacRec[posMedico]++;
                actualizarDatosMedici(arch,medicosIngMeds[posMedico],porcDcto,
                                      medicinCods,medicinPrecios,medicinCantVend,
                                      medicinIngSinD,medicinDctos,numMedicin);
            }
            else medicosPacNoRec[posMedico]++;
        }
        else while(arch.get() != '\n');
    }
}

void actualizarIngresoCita(double &medicosIngCitas,double duracionEnH,
                          double medicosTarifa,double porcDcto){
    medicosIngCitas += (duracionEnH*medicosTarifa)*(1-porcDcto/100);
}

void actualizarDatosMedici(ifstream &arch,double &medicosIngMeds, double porcDcto,
                          int *medicinCods,double *medicinPrecios,int *medicinCantVend,
                          double *medicinIngSinD,double *medicinDctos,int numMedicin){
    int codMedicina, cantMedicina, posMedicina;
    double precio, montoMedicinas=0;
    while(true){
        if(arch.get() == '\n') break;
        arch>>codMedicina>>cantMedicina;
        posMedicina = buscarPosicionMedicina(codMedicina,medicinCods,numMedicin);
        if(posMedicina != NO_ENCONTRADO){
            medicinCantVend[posMedicina] += cantMedicina;
            precio = medicinPrecios[posMedicina];
            medicinIngSinD[posMedicina] += (precio*cantMedicina);
            medicinDctos[posMedicina] += (precio*cantMedicina)*(porcDcto/200);
            montoMedicinas += (precio*cantMedicina)*(1-porcDcto/200);
        }
        else while(arch.get() != '\n');
    }
    medicosIngMeds += montoMedicinas;
}

int buscarPosicionMedico(int codMedico,int *medicosCods,int numMedicos){
    for(int i=0;i<numMedicos;i++)
        if(codMedico == medicosCods[i]) return i;
    return NO_ENCONTRADO;
}
int buscarPosicionMedicina(int codMedicina,int *medicinCods,int numMedicin){
    for(int i=0;i<numMedicin;i++)
        if(codMedicina==medicinCods[i]) return i;
    return NO_ENCONTRADO;
}
int leerObtenerHora(ifstream &arch){
    int hor,min,seg;
    char c;
    arch>>hor>>c>>min>>c>>seg;
    return (hor*3600 + min*60 + seg);
}

//IMPRIMIR EL REPORTE AHORA, !VAMOS!