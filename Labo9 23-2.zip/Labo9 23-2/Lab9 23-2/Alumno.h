/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * Archivo:   Alumno.h
 * Autor: VinKzzlo
 *
 * Creado el on 15 de junio de 2024, 2:06
 */

#ifndef ALUMNO_H
#define ALUMNO_H

struct Alumno{
    int codigo;
    char *nombre;
    char escala;
    double pagoXCred;
};

#endif /* ALUMNO_H */

