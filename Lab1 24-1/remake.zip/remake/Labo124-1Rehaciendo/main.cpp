
/* 
 * Archivo:   main.cpp
 * Autor: VinKzzlo 
 *
 * Creado el 14 de abril de 2024, 0:23
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "FuncionesParaReporte.h"

int main(int argc, char** argv) {
    
    EmitirReporte();
    
    return 0;
}

