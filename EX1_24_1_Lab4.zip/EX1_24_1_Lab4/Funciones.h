/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: USUARIO
 *
 * Created on 11 de mayo de 2024, 12:21
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerArchivosYImprimir(const char *nombArchMed, const char *nombArchMedic, 
                           const char *nombArchCitas, const char *nombArchRep);
void leerNombre(ifstream &archMed);

#endif /* FUNCIONES_H */

