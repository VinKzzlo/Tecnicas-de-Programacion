/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   ArticuloVendido.h
 * Author: Enzo Andre Avila Mamani (20220954)
 *
 * Created on 20 de noviembre de 2023, 07:07 PM
 */

#ifndef ARTICULOVENDIDO_H
#define ARTICULOVENDIDO_H

struct ArticuloVendido{
    char codigo[8];
    int cantVendida;
    double montoTotal;
    double pago;
};

#endif /* ARTICULOVENDIDO_H */

