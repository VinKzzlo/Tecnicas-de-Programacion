/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Articulo.h
 * Author: Enzo Andre Avila Mamani (20220954)
 *
 * Created on 20 de noviembre de 2023, 07:07 PM
 */

#ifndef ARTICULO_H
#define ARTICULO_H

struct Articulo{
    char codigo[8];
    char descripcion[60];
    double precio;
    int cantVendida;
    double montoVendido;
};

#endif /* ARTICULO_H */

