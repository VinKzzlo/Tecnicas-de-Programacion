/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Vendedor.h
 * Author: Enzo Andre Avila Mamani (20220954)
 *
 * Created on 20 de noviembre de 2023, 07:07 PM
 */

#ifndef VENDEDOR_H
#define VENDEDOR_H
#include "ArticuloVendido.h"

struct Vendedor{
    int codigo;
    char nombre[60];
    double porcentaje;
    double cuotaMin;
    struct ArticuloVendido articulos[30];
    int cantArticulos;
    double montoTotal;
    bool superoCuota;
};

#endif /* VENDEDOR_H */

