/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

/* 
 * File:   funciones.cpp
 * Author: Enzo Andre Avila Mamani (20220954)
 *
 * Created on 20 de noviembre de 2023, 07:07 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

#define NO_ENCONTRADO -1
#define TAM_LINEA 130
#include "ArticuloVendido.h"
#include "Articulo.h"
#include "Vendedor.h"
#include "funciones.h"

void crearArticulosBin(const char *nombArchCsv,const char *nombArchBin){
    ifstream archArticulosCsv(nombArchCsv,ios::in);
    if(not archArticulosCsv.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchCsv<<endl; 
        exit(1);
    }
    ofstream archArticulosBin(nombArchBin,ios::out|ios::binary);
    if(not archArticulosBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchBin<<endl;
        exit(1);
    }
    struct Articulo dato;
    while(true){
        archArticulosCsv.getline(dato.codigo,8,',');
        if(archArticulosCsv.eof()) break;
        archArticulosCsv.getline(dato.descripcion,60,',');
        pasarAMayus(dato.descripcion);
        archArticulosCsv>>dato.precio;
        archArticulosCsv.get();
        dato.cantVendida=0;
        dato.montoVendido=0;
        archArticulosBin.write(reinterpret_cast<const char*>(&dato),
                sizeof(struct Articulo));
    }
}

void pasarAMayus(char *articulo){
    for(int i=0;articulo[i];i++){
        if(articulo[i]>='a' and articulo[i]<='z') articulo[i]+='A'-'a';
    }
}

void mostrarArticulosBin(const char *nombArchBin){
    ifstream archBin(nombArchBin,ios::in|ios::binary);
    if(not archBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchBin<<endl;
        exit(1);
    }
    struct Articulo dato;
    cout<<setprecision(2)<<fixed;
    while(true){
        archBin.read(reinterpret_cast<char*>(&dato),sizeof(struct Articulo));
        if(archBin.eof()) break;
        cout<<dato.codigo<<' '<<dato.descripcion<<' '<<dato.precio<<
                ' '<<dato.cantVendida<<' '<<dato.montoVendido<<endl;
    }
}

void crearVendedoresBin(const char *nombArchCsv,const char *nombArchBin){
    ifstream archVendedoresCsv(nombArchCsv,ios::in);
    if(not archVendedoresCsv.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchCsv<<endl; 
        exit(1);
    }
    ofstream archVendedoresBin(nombArchBin,ios::out|ios::binary);
    if(not archVendedoresBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchBin<<endl;
        exit(1);
    }
    struct Vendedor dato;
    while(true){
        archVendedoresCsv>>dato.codigo;
        if(archVendedoresCsv.eof()) break;
        archVendedoresCsv.get();
        archVendedoresCsv.getline(dato.nombre,60,',');
        modificarNombre(dato.nombre);
        archVendedoresCsv>>dato.porcentaje;
        archVendedoresCsv.get();
        archVendedoresCsv>>dato.cuotaMin;
        dato.montoTotal=0;
        dato.cantArticulos=0;
        dato.superoCuota=true;
        archVendedoresBin.write(reinterpret_cast<const char*>(&dato),
                sizeof(struct Vendedor));
    }
}

void modificarNombre(char *nombre){
    bool mayus=true;
    for(int i=0;nombre[i];i++){
        if(nombre[i]!='-' and nombre[i]!='/' and mayus) mayus=false;
        else if(nombre[i]!='-' and nombre[i]!='/' and !mayus){
            nombre[i]+='a'-'A';
        }
        else if(nombre[i]=='-' or nombre[i]=='/'){
            mayus=true;
            nombre[i]=' ';
        }
    }
}

void mostrarVendedoresBin(const char *nombArchBin){
    ifstream archBin(nombArchBin,ios::in|ios::binary);
    struct Vendedor dato;
    while(true){
        archBin.read(reinterpret_cast<char*>(&dato),sizeof(struct Vendedor));
        if(archBin.eof()) break;
        cout<<setprecision(2)<<fixed;
        cout<<dato.codigo<<' '<<dato.nombre<<' '<<dato.porcentaje<<' '<<
                dato.cuotaMin<<endl;
        for(int i=0;i<dato.cantArticulos;i++){
            cout<<setw(2)<<' '<<dato.articulos[i].codigo<<' '<<dato.articulos[i].cantVendida<<
                    ' '<<dato.articulos[i].montoTotal<<' '<<dato.articulos[i].pago<<endl;
        }
    }
}

void analizarVentas(const char *nombArchVentas,const char *nombArchArticulosBin,
        const char *nombArchVendedoresBin){
    ifstream archVentas(nombArchVentas,ios::in);
    if(not archVentas.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchVentas<<endl;
        exit(1);
    }
    fstream archArticulosBin(nombArchArticulosBin,ios::in|ios::out|ios::binary);
    if(not archArticulosBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchArticulosBin<<endl;
        exit(1);
    }
    fstream archVendedoresBin(nombArchVendedoresBin,ios::in|ios::out|ios::binary);
    if(not archVendedoresBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchVendedoresBin<<endl;
        exit(1);
    }
    char codigo[8];
    int codigoVend,cantidad,tamRegArt,tamRegVend,numRegArt,numRegVend,posArt,posVend;
    double precio;
    tamRegArt=sizeof(struct Articulo);
    tamRegVend=sizeof(struct Vendedor);
    numRegArt=calcularNumReg(archArticulosBin,tamRegArt);
    numRegVend=calcularNumReg(archVendedoresBin,tamRegVend);
    while(true){
        archVentas>>codigo;
        if(archVentas.eof()) break;
        archVentas>>codigoVend>>cantidad;
        posArt=buscarArticulo(archArticulosBin,codigo,numRegArt);
        posVend=buscarVendedor(archVendedoresBin,codigoVend,numRegVend);
        if(posArt!=NO_ENCONTRADO and posVend!=NO_ENCONTRADO){
            modificarArchArticulos(archArticulosBin,codigo,codigoVend,
                cantidad,posArt,precio);
            modificarArchVendedores(archVendedoresBin,codigo,codigoVend,
                    cantidad,posVend,precio);
        }   
    }
}

void modificarArchArticulos(fstream &archArticulosBin,char *codigo,int codigoVend,
        int cantidad,int posArt,double &precio){
    struct Articulo datoArticulo;
    int tamReg,numReg;
    tamReg=sizeof(struct Articulo);
    numReg=calcularNumReg(archArticulosBin,tamReg);
    archArticulosBin.seekg(posArt*tamReg,ios::beg);
    archArticulosBin.read(reinterpret_cast<char*>(&datoArticulo),tamReg);
    precio=datoArticulo.precio;
    datoArticulo.cantVendida+=cantidad;
    datoArticulo.montoVendido+=cantidad*datoArticulo.precio;
    archArticulosBin.seekg(posArt*tamReg,ios::beg);
    archArticulosBin.write(reinterpret_cast<const char*>(&datoArticulo),tamReg);
    archArticulosBin.flush();
}

void modificarArchVendedores(fstream &archVendedoresBin,char *codigo,int codigoVend,
        int cantidad,int posVend,double precio){
    struct Vendedor datoVendedor;
    int tamReg,numReg,posArticulo;
    tamReg=sizeof(struct Vendedor);
    numReg=calcularNumReg(archVendedoresBin,tamReg);
    archVendedoresBin.seekg(posVend*tamReg,ios::beg);
    archVendedoresBin.read(reinterpret_cast<char*>(&datoVendedor),tamReg);
    posArticulo=buscarArtEnVendedor(datoVendedor.articulos,codigo,datoVendedor.cantArticulos);
    if(posArticulo!=NO_ENCONTRADO){
        datoVendedor.articulos[posArticulo].cantVendida+=cantidad;
        datoVendedor.articulos[posArticulo].montoTotal+=cantidad*precio;
        datoVendedor.articulos[posArticulo].pago+=cantidad*precio*(datoVendedor.porcentaje/100);
    }
    else{
        strcpy(datoVendedor.articulos[datoVendedor.cantArticulos].codigo,codigo);
        datoVendedor.articulos[datoVendedor.cantArticulos].cantVendida=cantidad;
        datoVendedor.articulos[datoVendedor.cantArticulos].montoTotal=cantidad*precio;
        datoVendedor.articulos[datoVendedor.cantArticulos].pago=cantidad*precio*
                (datoVendedor.porcentaje/100);
        datoVendedor.cantArticulos++;
    }
    archVendedoresBin.seekg(posVend*tamReg,ios::beg);
    archVendedoresBin.write(reinterpret_cast<const char*>(&datoVendedor),tamReg);
    archVendedoresBin.flush();
}

int buscarArtEnVendedor(struct ArticuloVendido *articulos,char *codigo,int numArticulos){
    for(int i=0;i<numArticulos;i++){
        if(strcmp(articulos[i].codigo,codigo)==0) return i;
    }
    return NO_ENCONTRADO;
}

int buscarArticulo(fstream &archBin,char *codigo,int numReg){
    struct Articulo datoArticulo;
    archBin.seekg(0,ios::beg);
    for(int i=0;i<numReg;i++){
        archBin.read(reinterpret_cast<char*>(&datoArticulo),sizeof(struct Articulo));
        if(strcmp(datoArticulo.codigo,codigo)==0) return i;
    }
    return NO_ENCONTRADO;
}

int buscarVendedor(fstream &archBin,int codigo,int numReg){
    struct Vendedor dato;
    archBin.seekg(0,ios::beg);
    for(int i=0;i<numReg;i++){
        archBin.read(reinterpret_cast<char*>(&dato),sizeof(struct Vendedor));
        if(dato.codigo==codigo) return i;
    }
    return NO_ENCONTRADO;
}

int calcularNumReg(fstream &archBin,int tamReg){
    int tamArch;
    archBin.seekg(0,ios::end);
    tamArch=archBin.tellg();
    archBin.seekg(0,ios::beg);
    return tamArch/tamReg;
}

void corregirVendedoresBin(const char *nombArchBin){
    fstream archVendedoresBin(nombArchBin,ios::in|ios::out|ios::binary);
    if(not archVendedoresBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchBin<<endl;
        exit(1);
    }
    struct Vendedor datoVendedor;
    int tamReg=sizeof(struct Vendedor);
    int numReg=calcularNumReg(archVendedoresBin,tamReg);
    for(int i=0;i<numReg;i++){
        archVendedoresBin.read(reinterpret_cast<char*>(&datoVendedor),tamReg);
        for(int j=0;j<datoVendedor.cantArticulos;j++){
            datoVendedor.montoTotal+=datoVendedor.articulos[j].montoTotal;
        }
        if(datoVendedor.montoTotal<=datoVendedor.cuotaMin){
            datoVendedor.superoCuota=false;
            datoVendedor.montoTotal=0;
            for(int k=0;k<datoVendedor.cantArticulos;k++){
                datoVendedor.articulos[k].pago=0;
            }
        }
        else datoVendedor.montoTotal*=datoVendedor.porcentaje/100;
        archVendedoresBin.seekg(i*tamReg,ios::beg);
        archVendedoresBin.write(reinterpret_cast<const char*>(&datoVendedor),tamReg);
        archVendedoresBin.flush();
    }
}
 
void ordenarVendedoresBin(const char *nombArchBin){
    fstream archVendedoresBin(nombArchBin,ios::in|ios::out|ios::binary);
    if(not archVendedoresBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchBin<<endl;
        exit(1);
    }
    struct Vendedor dato1,dato2;
    int tamReg=sizeof(struct Vendedor);
    int numReg=calcularNumReg(archVendedoresBin,tamReg);
    for(int i=0;i<numReg-1;i++){
        for(int j=i+1;j<numReg;j++){
            archVendedoresBin.seekg(i*tamReg,ios::beg);
            archVendedoresBin.read(reinterpret_cast<char*>(&dato1),tamReg);
            archVendedoresBin.seekg(j*tamReg,ios::beg);
            archVendedoresBin.read(reinterpret_cast<char*>(&dato2),tamReg);
            if(dato2.montoTotal>dato1.montoTotal){
                archVendedoresBin.seekg(i*tamReg,ios::beg);
                archVendedoresBin.write(reinterpret_cast<const char*>(&dato2),tamReg);
                archVendedoresBin.seekg(j*tamReg,ios::beg);
                archVendedoresBin.write(reinterpret_cast<const char*>(&dato1),tamReg);
                archVendedoresBin.flush();
            }
        }
    }
}

void emitirReporte(const char *nombArchVendedoresBin,const char *nombArticulosBin,
        const char *nombArchReporte){
    ofstream archReporte(nombArchReporte,ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchReporte<<endl;
        exit(1);
    }
    ifstream archArticulosBin(nombArticulosBin,ios::in|ios::binary);
    if(not archArticulosBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArticulosBin<<endl;
        exit(1);
    }
    ifstream archVendedoresBin(nombArchVendedoresBin,ios::in|ios::binary);
    if(not archVendedoresBin.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArchVendedoresBin<<endl;
        exit(1);
    }
    double ingresoTotal=0,pagoTotal=0;
    archReporte<<setprecision(2)<<fixed;
    archReporte<<setw(40)<<' '<<"TIENDA POR DEPARTAMENTOS TP"<<endl<<endl;
    archReporte<<setw(35)<<' '<<"DETALLE DE PAGOS A LOS VENDEDORES"<<endl;
    imprimirVendedores(archReporte,archVendedoresBin,archArticulosBin,pagoTotal);
    imprimirEncabezadoArticulos(archReporte);
    imprimirArticulos(archReporte,archArticulosBin,ingresoTotal);
    imprimirLinea(archReporte,TAM_LINEA,'=');
    archReporte<<"TOTAL DE INGRESOS POR VENTAS, DESCONTANDO PAGOS: "<<
            ingresoTotal-pagoTotal<<endl;
    imprimirLinea(archReporte,TAM_LINEA,'=');
}

void imprimirEncabezadoVendedores(ofstream &archReporte){
    imprimirLinea(archReporte,TAM_LINEA,'=');
    archReporte<<"No. "<<setw(4)<<' '<<"VENDEDOR"<<setw(43)<<' '<<"% POR VENTAS"
            <<setw(3)<<' '<<"CUOTA MINIMA"<<' '<<setw(6)<<' '<<"OBSERVACION"<<endl;
    imprimirLinea(archReporte,TAM_LINEA,'-');
}

void imprimirVendedores(ofstream &archReporte,ifstream &archVendedoresBin,
        ifstream &archArticulosBin,double &pagoTotal){
    struct Vendedor dato;
    int contador=0;
    while(true){
        archVendedoresBin.read(reinterpret_cast<char*>(&dato),sizeof(struct Vendedor));
        if(archVendedoresBin.eof()) break;
        imprimirEncabezadoVendedores(archReporte);
        contador++;
        archReporte<<setfill('0')<<setw(3)<<contador<<')'<<setfill(' ')<<setw(4)<<' '<<
                dato.codigo<<setw(4)<<' '<<left<<setw(41)<<dato.nombre<<right<<
                setw(6)<<dato.porcentaje<<'%'<<setw(17)<<dato.cuotaMin<<setw(5)<<' ';
        if(!dato.superoCuota) archReporte<<"NO SUPERO LA CUOTA"<<endl;
        else{
            archReporte<<endl;
            archReporte<<setw(8)<<' '<<"ARTICULOS VENDIDOS"<<endl;
            archReporte<<setw(8)<<' '<<"No."<<setw(2)<<' '<<"ARTICULO"<<setw(60)<<' '<<
                    "CANTIDAD"<<setw(6)<<' '<<"TOTAL"<<setw(4)<<' '<<"PAGO POR VENTAS"<<endl;
            for(int i=0;i<dato.cantArticulos;i++){
                archReporte<<setw(8)<<' '<<setfill('0')<<setw(2)<<i+1<<')'<<setfill(' ')
                    <<setw(2)<<' '<<dato.articulos[i].codigo<<setw(3)<<' ';
                buscarImprimirNombre(archReporte,archArticulosBin,dato.articulos[i].codigo);
                archReporte<<setw(3)<<dato.articulos[i].cantVendida<<setw(15)<<
                        dato.articulos[i].montoTotal<<setw(15)<<dato.articulos[i].pago<<endl;
            }
        }
        archReporte<<"TOTAL DE PAGOS POR VENTAS: "<<dato.montoTotal<<endl;
        pagoTotal+=dato.montoTotal;
    }
}

void buscarImprimirNombre(ofstream &archReporte,ifstream &archArticulosBin,
        const char *codigo){
    struct Articulo dato;
    int tamReg=sizeof(struct Articulo),numReg,tamArch;
    archArticulosBin.seekg(0,ios::end);
    tamArch=archArticulosBin.tellg();
    archArticulosBin.seekg(0,ios::beg);
    numReg=tamArch/tamReg;
    for(int i=0;i<numReg;i++){
        archArticulosBin.read(reinterpret_cast<char*>(&dato),tamReg);
        if(strcmp(dato.codigo,codigo)==0){
            archReporte<<left<<setw(60)<<dato.descripcion<<right;
            break;
        }
    }
    archArticulosBin.seekg(0,ios::beg);
}

void imprimirEncabezadoArticulos(ofstream &archReporte){
    imprimirLinea(archReporte,TAM_LINEA,'=');
    archReporte<<endl<<setw(40)<<' '<<"DETALLE DE INGRESOS POR ARTICULO"<<endl;
    imprimirLinea(archReporte,TAM_LINEA,'=');
    archReporte<<"No. "<<setw(3)<<' '<<"ARTICULO"<<setw(65)<<' '<<"PRECIO"<<
            setw(2)<<' '<<"CANTIDAD VENDIDA"<<setw(3)<<' '<<"INGRESOS POR VENTAS"<<
            endl;
    imprimirLinea(archReporte,TAM_LINEA,'-');
}

void imprimirArticulos(ofstream &archReporte,ifstream &archArticulosBin,
        double &ingresoTotal){
    struct Articulo dato;
    int contador=0;
    while(true){
        archArticulosBin.read(reinterpret_cast<char*>(&dato),sizeof(struct Articulo));
        if(archArticulosBin.eof()) break;
        contador++;
        archReporte<<setfill('0')<<setw(3)<<contador<<')'<<setfill(' ')<<
                setw(3)<<' '<<dato.codigo<<setw(3)<<' '<<left<<setw(60)<<
                dato.descripcion<<right<<setw(10)<<dato.precio<<setw(10)<<
                dato.cantVendida<<setw(24)<<dato.montoVendido<<endl;
        ingresoTotal+=dato.montoVendido;
    }
}

void imprimirLinea(ofstream &archReporte,int longitud,char simbolo){
    for(int i=0;i<longitud;i++) archReporte.put(simbolo);
    archReporte<<endl;
}
