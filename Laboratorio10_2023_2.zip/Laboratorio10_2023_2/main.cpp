/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Enzo Andre Avila Mamani (20220954)
 *
 * Created on 20 de noviembre de 2023, 07:07 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#include "ArticuloVendido.h"
#include "Articulo.h"
#include "Vendedor.h"
#include "funciones.h"

int main(int argc, char** argv) {
    
    crearArticulosBin("Articulos.csv","Articulos.bin");
    crearVendedoresBin("Vendedores.csv","Vendedores.bin");
    analizarVentas("Ventas.txt","Articulos.bin","Vendedores.bin");
//    mostrarArticulosBin("Articulos.bin");
    corregirVendedoresBin("Vendedores.bin");
    ordenarVendedoresBin("Vendedores.bin");
    emitirReporte("Vendedores.bin","Articulos.bin","Reporte.txt");
    return 0;
}

