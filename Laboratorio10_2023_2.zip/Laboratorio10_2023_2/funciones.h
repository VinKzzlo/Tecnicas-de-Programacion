/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: Enzo Andre Avila Mamani (20220954)
 *
 * Created on 20 de noviembre de 2023, 07:07 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H
#include "ArticuloVendido.h"
#include "Articulo.h"
#include "Vendedor.h"

void crearArticulosBin(const char *nombArchCsv,const char *nombArchBin);
void pasarAMayus(char *articulo);
void mostrarArticulosBin(const char *nombArchBin);
void crearVendedoresBin(const char *nombArchCsv,const char *nombArchBin);
void modificarNombre(char *nombre);
void mostrarVendedoresBin(const char *nombArchBin);
void analizarVentas(const char *nombArchVentas,const char *nombArchArticulosBin,
        const char *nombArchVendedoresBin);
void modificarArchArticulos(fstream &archArticulosBin,char *codigo,int codigoVend,
        int cantidad,int posArt,double &precio);
void modificarArchVendedores(fstream &archVendedoresBin,char *codigo,int codigoVend,
        int cantidad,int posVend,double precio);
int buscarArtEnVendedor(struct ArticuloVendido *articulos,char *codigo,int numArticulos);
int buscarArticulo(fstream &archBin,char *codigo,int numReg);
int buscarVendedor(fstream &archBin,int codigo,int numReg);
int calcularNumReg(fstream &archBin,int tamReg);
void corregirVendedoresBin(const char *nombArchBin);
void ordenarVendedoresBin(const char *nombArchBin);
void emitirReporte(const char *nombArchVendedoresBin,const char *nombArticulosBin,
        const char *nombArchReporte);
void imprimirEncabezadoVendedores(ofstream &archReporte);
void imprimirVendedores(ofstream &,ifstream &,ifstream &,double &);
void buscarImprimirNombre(ofstream &archReporte,ifstream &archArticulosBin,
        const char *codigo);
void imprimirEncabezadoArticulos(ofstream &archReporte);
void imprimirArticulos(ofstream &archReporte,ifstream &archArticulosBin,double &);
void imprimirLinea(ofstream &archReporte,int longitud,char simbolo);

#endif /* FUNCIONES_H */

