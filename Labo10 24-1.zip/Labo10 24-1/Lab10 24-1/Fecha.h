/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * Archivo:   Fecha.h
 * Autor: VinKzzlo
 *
 * Creado el on 30 de junio de 2024, 2:04
 */

#ifndef FECHA_H
#define FECHA_H

struct Fecha{
    int dd;
    int mm;
    int aa;
    int fecha;
};

#endif /* FECHA_H */

