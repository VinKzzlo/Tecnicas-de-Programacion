/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * Archivo:   Cliente.h
 * Autor: VinKzzlo
 *
 * Creado el on 30 de junio de 2024, 2:03
 */

#ifndef CLIENTE_H
#define CLIENTE_H

struct Cliente{
    int dni;
    char nombre[60];
};

#endif /* CLIENTE_H */

