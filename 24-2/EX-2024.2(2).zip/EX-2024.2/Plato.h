/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Plato.h
 * Author: aml
 *
 * Created on 3 de julio de 2025, 11:18 AM
 */

#ifndef PLATO_H
#define PLATO_H

struct Plato{
    char *codigo;
    char *nombre;
    double precio;
    int cantidad;
};



#endif /* PLATO_H */

