/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Plato.h
 * Autor:  VinKzzlo
 *
 * Creado el 3 de julio de 2025, 22:12
 */

#ifndef PLATO_H
#define PLATO_H

struct Plato{
    char *codigo;
    char *nombre;
    double precio;
    int cantidad;
};

#endif /* PLATO_H */

