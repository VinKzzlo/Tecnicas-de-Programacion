/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Palabra.h
 * Autor:  VinKzzlo
 *
 * Creado el 3 de julio de 2025, 22:11
 */

#ifndef PALABRA_H
#define PALABRA_H

struct Palabra{
    char *texto;
    int polaridad;
};

#endif /* PALABRA_H */

