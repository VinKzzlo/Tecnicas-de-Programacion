/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * Archivo:   UsuarioConElLibro.h
 * Autor: VinKzzlo
 *
 * Creado el on 1 de julio de 2024, 17:10
 */

#ifndef USUARIOCONELLIBRO_H
#define USUARIOCONELLIBRO_H

struct UsuarioConElLibro{
    int dni;
    int fechaDeDevolucion;
};

#endif /* USUARIOCONELLIBRO_H */

