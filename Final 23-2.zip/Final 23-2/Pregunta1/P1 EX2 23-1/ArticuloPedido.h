/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * Archivo:   ArticuloPedido.h
 * Autor: VinKzzlo
 *
 * Creado el on 30 de junio de 2024, 20:45
 */

#ifndef ARTICULOPEDIDO_H
#define ARTICULOPEDIDO_H

struct ArticuloPedido{
    char *codigo;
    int cantidad;
    int fechaUltPed;
    double montoTotal;
};

#endif /* ARTICULOPEDIDO_H */

