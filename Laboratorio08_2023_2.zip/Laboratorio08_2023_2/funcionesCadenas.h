/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcionesCadenas.h
 *
 * Created on 6 de noviembre de 2023, 07:08 PM
 */

#ifndef FUNCIONESCADENAS_H
#define FUNCIONESCADENAS_H

void modificarNombre(char *nombre);

#endif /* FUNCIONESCADENAS_H */

