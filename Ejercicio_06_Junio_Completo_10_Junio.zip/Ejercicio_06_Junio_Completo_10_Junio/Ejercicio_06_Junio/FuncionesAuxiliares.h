/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   FuncionesAuxiliares.h
 * Author: aml
 *
 * Created on 6 de junio de 2024, 10:21 AM
 */

#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H

void leerAlumnos(const char*nombArch,struct Alumno *alumnos,int &numAlumn);
void imprimirAlumnos(const char*nombArch,struct Alumno *alumnos,int numAlumn);
void ordenarAlumnos(struct Alumno *alumnos,int numAlumn);
void cambiar(struct Alumno &alumnosI,struct Alumno &alumnosK);
void leerCursos(const char *nombArch,struct Alumno *alumnos,int numAlumn);
int buscarAlumno(int codAlumno,struct Alumno *alumnos,int numAlumn);
void imprimirNotas(ofstream &arch,struct Curso *cursos,int numCurs);
void ordenarCursosDeCadaAlumno(struct Alumno *alumnos,int numAlumn);
void ordenarCursos(struct Curso *cursos,int numCurso);
void cambiarC(struct Curso &cursoI,struct Curso &cursoK);
void calcularPromedios(struct Alumno *alumnos,int numAlumn);
double promedio(struct Curso *cursos,int numCurso);

#endif /* FUNCIONESAUXILIARES_H */

