/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 6 de junio de 2024, 10:12 AM
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "Alumno.h"
#include "FuncionesAuxiliares.h"

int main(int argc, char** argv) {
    
    struct Alumno alumnos[50]{};
    int numAlumn;
    leerAlumnos("Alumnos.csv",alumnos,numAlumn);
    leerCursos("CursosNotas.csv",alumnos,numAlumn);
    ordenarAlumnos(alumnos,numAlumn);
    ordenarCursosDeCadaAlumno(alumnos,numAlumn);
    calcularPromedios(alumnos,numAlumn);
    imprimirAlumnos("ReporteDeAlumnos.txt",alumnos,numAlumn);
    
    
    return 0;
}

