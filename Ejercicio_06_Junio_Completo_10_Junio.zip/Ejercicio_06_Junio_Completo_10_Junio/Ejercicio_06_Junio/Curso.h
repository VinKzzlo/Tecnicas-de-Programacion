/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Curso.h
 * Author: aml
 *
 * Created on 6 de junio de 2024, 10:14 AM
 */

#ifndef CURSO_H
#define CURSO_H

struct Curso{
    char codigo[7];
    int nota;
};

#endif /* CURSO_H */

