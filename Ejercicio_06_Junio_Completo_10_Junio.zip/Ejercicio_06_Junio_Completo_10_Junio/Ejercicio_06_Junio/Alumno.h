/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Alumno.h
 * Author: aml
 *
 * Created on 6 de junio de 2024, 10:15 AM
 */

#ifndef ALUMNO_H
#define ALUMNO_H
#include "Curso.h"

struct Alumno{
    int codigo;
    char nombre[60];
    struct Curso cursos[70];
    int numCurso;
    double promedio;
};

#endif /* ALUMNO_H */

