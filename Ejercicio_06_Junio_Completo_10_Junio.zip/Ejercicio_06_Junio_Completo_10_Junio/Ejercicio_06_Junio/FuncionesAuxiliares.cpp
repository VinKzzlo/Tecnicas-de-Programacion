/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <random>
using namespace std;
#include "Alumno.h"
#include "FuncionesAuxiliares.h"
#define NO_ENCONTRADO -1

void leerAlumnos(const char*nombArch,struct Alumno *alumnos,int &numAlumn){
    ifstream arch(nombArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: no se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    numAlumn = 0;
    int codigo;
    char nombre[60];
    while(true){
        arch>>codigo;
        if(arch.eof()) break;
        arch.get();
        arch.getline(nombre,60);
        alumnos[numAlumn].codigo = codigo;
        strcpy(alumnos[numAlumn].nombre,nombre);
//        alumnos[numAlumn].numCurso = 0; mas facil poner llaves en el main
        numAlumn++;
    }
} 
void imprimirAlumnos(const char*nombArch,struct Alumno *alumnos,int numAlumn){
    
    ofstream arch(nombArch,ios::out);
    if(not arch.is_open()){
        cout<<"ERROR: no se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    arch.precision(2);
    arch<<fixed;
    for(int i=0; i<numAlumn; i++){
        arch<<setw(7)<<alumnos[i].codigo<<"   "
            <<left<<setw(50)<<alumnos[i].nombre<<endl;
        imprimirNotas(arch,alumnos[i].cursos,alumnos[i].numCurso);
        arch<<"Promedio: "<<setw(10)<<alumnos[i].promedio<<endl;;
    }   
}
void ordenarAlumnos(struct Alumno *alumnos,int numAlumn){
    for(int i=0; i<numAlumn-1; i++){
        for(int k=i+1; k<numAlumn; k++){
            if(strcmp(alumnos[i].nombre,alumnos[k].nombre)>0)
                cambiar(alumnos[i],alumnos[k]);
        }
    }
}
void cambiar(struct Alumno &alumnosI,struct Alumno &alumnosK){
    struct Alumno aux;
    aux = alumnosI;
    alumnosI = alumnosK;
    alumnosK = aux;
//    strcpy(aux,alumnosI);
//    strcpy(alumnosI,alumnosK);
//    strcpy(alumnosK,aux);
}
void leerCursos(const char *nombArch,struct Alumno *alumnos,int numAlumn){
    ifstream arch(nombArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: no se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    int codAlumno,nota,posiAlumno,numCurso;
    char codCurso[7];
    while(true){
        arch>>codAlumno;
        if(arch.eof()) break;
        arch.get(); //saca coma
        arch.getline(codCurso,7,',');
        arch>>nota;
        posiAlumno = buscarAlumno(codAlumno,alumnos,numAlumn);
        if(posiAlumno!=NO_ENCONTRADO){
            numCurso = alumnos[posiAlumno].numCurso;
            strcpy(alumnos[posiAlumno].cursos[numCurso].codigo,codCurso);
            alumnos[posiAlumno].cursos[numCurso].nota = nota;
            alumnos[posiAlumno].numCurso++;
        }
    }
}
int buscarAlumno(int codAlumno,struct Alumno *alumnos,int numAlumn){
    for(int i=0; i<numAlumn; i++){
        if(codAlumno==alumnos[i].codigo) return i;
    }
    return NO_ENCONTRADO;
}
void imprimirNotas(ofstream &arch,struct Curso *cursos,int numCurs){
    for(int k=0; k<numCurs; k++){
        arch<<setw(15)<<right<<cursos[k].codigo<<setw(10)
            <<cursos[k].nota<<endl;
    }
}
void ordenarCursosDeCadaAlumno(struct Alumno *alumnos,int numAlumn){
    for(int i=0; i<numAlumn-1; i++){
        ordenarCursos(alumnos[i].cursos,alumnos[i].numCurso);
//        for(int k=i+1; k<numAlumn; k++){
//            if(alumnos[i].nombre,alumnos[k].nombre)>0)
//                cambiar(alumnos[i],alumnos[k]);
//        }
    }
}
void ordenarCursos(struct Curso *cursos,int numCurso){
    for(int i=0; i<numCurso-1; i++){
        for(int k=i+1; k<numCurso; k++){
            if(cursos[i].nota<cursos[k].nota or
               cursos[i].nota == cursos[k].nota and
               strcmp(cursos[i].codigo,cursos[k].codigo)>0)
                    cambiarC(cursos[i],cursos[k]);
        }
    }
}
void cambiarC(struct Curso &cursoI,struct Curso &cursoK){
    struct Curso aux;
    aux = cursoI;
    cursoI = cursoK;
    cursoK = aux;    
}
void calcularPromedios(struct Alumno *alumnos,int numAlumn){
    for(int i=0; i<numAlumn; i++){
        alumnos[i].promedio = promedio(alumnos[i].cursos,alumnos[i].numCurso);
    }
}
double promedio(struct Curso *cursos,int numCurso){
    int suma=0;
    double promedio=0.0;
    if(numCurso>0){
        for(int i=0; i<numCurso; i++){
            suma += cursos[i].nota;
        }
        promedio = (double)suma/numCurso;
    }
    return promedio;
}