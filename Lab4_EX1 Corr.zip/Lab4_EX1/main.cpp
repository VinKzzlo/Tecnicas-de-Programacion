/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * Archivo:   main.cpp
 * Autor: Alessandro Piero Ledesma Guerra
 * Creado el 4 de mayo de 2024, 07:49 PM
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "Funciones.h"

int main(int argc, char** argv) {
    
    emitirReporte("Reporte.txt", "Medicinas.txt", "Medicos.txt", "CitasMedicas.txt");
    
    
    return 0;
}


