/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Facultad.h
 * Author: Alessandro Salvador Santé Vega - 20223006
 *
 * Created on 10 de junio de 2024, 07:16 PM
 */

#ifndef FACULTAD_H
#define FACULTAD_H

struct Facultad{
    char codigo[12];
    char nombre[50];
};

#endif /* FACULTAD_H */

