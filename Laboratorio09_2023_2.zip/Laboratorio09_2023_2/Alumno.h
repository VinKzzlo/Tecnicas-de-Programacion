/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Alumno.h

 *
 * Created on 13 de noviembre de 2023, 07:05 PM
 */

#ifndef ALUMNO_H
#define ALUMNO_H

struct Alumno{
    int codigo;
    char *nombre;
    char escala;
    double pago;
};

#endif /* ALUMNO_H */

