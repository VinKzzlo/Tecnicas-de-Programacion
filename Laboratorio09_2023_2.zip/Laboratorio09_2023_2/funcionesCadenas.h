/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funcionesCadenas.h
 *
 * Created on 13 de noviembre de 2023, 07:05 PM
 */

#ifndef FUNCIONESCADENAS_H
#define FUNCIONESCADENAS_H

char *leeCadenaExacta(ifstream &archivo);
void modificaNomCurso(char *curso);

#endif /* FUNCIONESCADENAS_H */

