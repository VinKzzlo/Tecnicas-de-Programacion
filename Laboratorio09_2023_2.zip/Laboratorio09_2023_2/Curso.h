/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Curso.h

 *
 * Created on 13 de noviembre de 2023, 07:06 PM
 */

#include "Alumno.h"

#ifndef CURSO_H
#define CURSO_H

struct Curso{
    int codigo;
    char *nombre;
    double creditos;
    struct Alumno *alumnos;
    int cantMatriculados;
    double ingresos;
};

#endif /* CURSO_H */

