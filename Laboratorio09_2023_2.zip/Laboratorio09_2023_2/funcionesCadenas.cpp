/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

/* 
 * File:   funcionesCadenas.cpp
 *
 * Created on 13 de noviembre de 2023, 07:05 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

#include "funcionesCadenas.h"

char *leeCadenaExacta(ifstream &archivo){
    char cadena[100], *ptr_cadena;
    int longCC;
    archivo.getline(cadena,100,',');
    longCC=strlen(cadena);
    ptr_cadena = new char [longCC+1];
    strcpy(ptr_cadena,cadena);
    return ptr_cadena;
}

void modificaNomCurso(char *curso){
    int i=0;
    while(true){
        if(curso[i]==0) break;
        curso[i]-=(curso[i]>='a' and curso[i]<='z'?'a'-'A':0);
        i++;
    }
}