/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h

 *
 * Created on 13 de noviembre de 2023, 07:05 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void solicitarDatos(int &);
void cargarEscalas(struct Escala *arrEscalas, int &cantEscalas);
void cargarCursos(struct Curso *arrCursos, int &cantCursos);
void actualizarMatricula(struct Escala *arrEscalas, int cantEscalas,
        struct Curso *arrCursos, int cantCursos, int);
int buscarCurso(const struct Curso *arrCursos,int cantCursos, int codCurso);
void actualizarAlumnos(struct Curso *arrCursos, int cantCursos, const struct Escala *arrEscalas,
        int cantEscalas, int);
int buscarEscala(const struct Escala *arrEscalas,int cantEscalas,char escala,int);
void ordenarDatos(struct Curso *arrCursos,int cantCursos);
void cambiarCursos(struct Curso &cursoI, struct Curso &cursoJ);
void ordenarAlumnos(struct Alumno *arrAlumnos,int cantAlumnos);
void cambiarAlumnos(struct Alumno &alumnoI, struct Alumno &alumnoJ);
void emitirReporte(const struct Curso *arrCursos,int cantCursos, int);
void imprimirPorAlumno(struct Alumno *arrAlumnos,int cantAlumnos, double creditos, ofstream &archReporte);
void imprimirLinea(char simbolo, int cant, ofstream &archReporte);

#endif /* FUNCIONES_H */

