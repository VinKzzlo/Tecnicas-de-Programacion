/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 *
 * Created on 13 de noviembre de 2023, 07:04 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#define tam_escalas 30
#define tam_cursos 100

using namespace std;

#include "funciones.h"
#include "Alumno.h"
#include "Escala.h"
#include "Curso.h"

/*
 * 
 */
int main(int argc, char** argv) {
    int ciclo;
    
    struct Escala arrEscalas[tam_escalas];
    int cantEscalas = 0;
    
    struct Curso *arrCursos;
    int cantCursos = 0;
    arrCursos = new struct Curso [tam_cursos];
    
    solicitarDatos(ciclo);
    cargarEscalas(arrEscalas, cantEscalas);
    cargarCursos(arrCursos,cantCursos);
    actualizarMatricula(arrEscalas, cantEscalas, arrCursos, cantCursos,ciclo);
    ordenarDatos(arrCursos,cantCursos);
    emitirReporte(arrCursos,cantCursos, ciclo);
    return 0;
}

