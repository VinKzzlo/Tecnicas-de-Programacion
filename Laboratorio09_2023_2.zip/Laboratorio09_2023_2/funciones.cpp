/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

/* 
 * File:   funciones.cpp
 *
 * Created on 13 de noviembre de 2023, 07:05 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#define max_alumnos 50
#define veces 120
#define NO_ENCONTRADO -1

using namespace std;

#include "funciones.h"
#include "funcionesCadenas.h"
#include "Alumno.h"
#include "Escala.h"
#include "Curso.h"

void solicitarDatos(int &semestre){
    int anho, mitad;
    cout<<"Ingrese un anho:"<<endl;
    cin>>anho;
    cout<<"Ingrese un semestre del anho a evaluar:"<<endl;
    cin>>mitad;
    semestre=anho*10+mitad;
}

void cargarEscalas(struct Escala *arrEscalas, int &cantEscalas){
    int anho, mitad;
    char car, escala;
    double valorCredito;
    ifstream archEscalas("Escalas.csv",ios::in);
    if(not archEscalas.is_open()){
        cout<<"Error en la apertura del archivo Escalas.csv"<<endl;
        exit(1);
    }
    while(true){
        archEscalas>>anho;
        if(archEscalas.eof()) break;
        archEscalas>>car>>mitad>>car>>escala>>car>>valorCredito;
        arrEscalas[cantEscalas].semestre=anho*10+mitad;
        arrEscalas[cantEscalas].escala=escala;
        arrEscalas[cantEscalas].valorCredito=valorCredito;
        cantEscalas++;
    }
}

void cargarCursos(struct Curso *arrCursos, int &cantCursos){
    int codigo;
    double creditos;
    char *ptr_nombre;
    ifstream archCursos("Cursos.csv",ios::in);
    if(not archCursos.is_open()){
        cout<<"Error en la apertura del archivo Cursos.csv"<<endl;
        exit(1);
    }
    while(true){
        archCursos>>codigo;
        if(archCursos.eof()) break;
        archCursos.get();
        ptr_nombre = leeCadenaExacta(archCursos);
        archCursos>>creditos;
        modificaNomCurso(ptr_nombre);
        arrCursos[cantCursos].codigo=codigo;
        arrCursos[cantCursos].nombre=ptr_nombre;
        arrCursos[cantCursos].creditos=creditos;
        arrCursos[cantCursos].alumnos=new struct Alumno[max_alumnos];
        arrCursos[cantCursos].cantMatriculados=0;
        arrCursos[cantCursos].ingresos=0;
        cantCursos++;
    }
}

void actualizarMatricula(struct Escala *arrEscalas, int cantEscalas,
        struct Curso *arrCursos, int cantCursos, int ciclo){
    int anho, mitad, codAlumno, codCurso, posCurso;
    char car;
    ifstream archMatricula("Matricula.csv",ios::in);
    if(not archMatricula.is_open()){
        cout<<"Error en la apertura del archivo Matricula.csv"<<endl;
        exit(1);
    }
    while(true){
        archMatricula>>anho;
        if(archMatricula.eof()) break;
        archMatricula>>car>>mitad;
        if(anho*10+mitad==ciclo){
            archMatricula>>car>>codAlumno>>car;
            while(true){
                archMatricula>>codCurso;
                posCurso=buscarCurso(arrCursos, cantCursos, codCurso);
                if(posCurso!=NO_ENCONTRADO){
                    arrCursos[posCurso].alumnos[arrCursos[posCurso].cantMatriculados].codigo=codAlumno;
                    arrCursos[posCurso].cantMatriculados++;
                }
                if(archMatricula.get()=='\n') break;
            }
        } else while(archMatricula.get()!='\n');
    }
    actualizarAlumnos(arrCursos, cantCursos, arrEscalas, cantEscalas, ciclo);
}

int buscarCurso(const struct Curso *arrCursos,int cantCursos, int codCurso){
    for(int i=0;i<cantCursos;i++)
        if(arrCursos[i].codigo==codCurso) return i;
    return NO_ENCONTRADO;
}

void actualizarAlumnos(struct Curso *arrCursos, int cantCursos, const struct Escala *arrEscalas,
        int cantEscalas, int ciclo){
    int codigo, posEscala;
    char escala, *ptr_nombre;
    ifstream archAlumnos("Alumnos.csv",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"Error en la apertura del archivo Alumnos.csv"<<endl;
        exit(1);
    }
    while(true){
        archAlumnos>>codigo;
        if(archAlumnos.eof()) break;
        archAlumnos.get();
        ptr_nombre = leeCadenaExacta(archAlumnos);
        escala = archAlumnos.get();
        for(int i=0;i<cantCursos;i++)
            for(int j=0;j<arrCursos[i].cantMatriculados;j++)
                if(arrCursos[i].alumnos[j].codigo==codigo){
                    arrCursos[i].alumnos[j].nombre=ptr_nombre;
                    arrCursos[i].alumnos[j].escala=escala;
                    posEscala=buscarEscala(arrEscalas,cantEscalas,escala,ciclo);
                    //luego de buscar la escala, si esta no existe le he colocado el valor de 0, para que esta
                    //no afecte a los calculos posteriores del credito. Si bien es improbable, se debe de 
                    // tener en cuenta
                    if(posEscala!=NO_ENCONTRADO)
                        arrCursos[i].alumnos[j].pago=arrEscalas[posEscala].valorCredito;
                    else
                        arrCursos[i].alumnos[j].pago=0;
                    arrCursos[i].ingresos+=arrCursos[i].alumnos[j].pago*arrCursos[i].creditos;
                }
    }
}

int buscarEscala(const struct Escala *arrEscalas,int cantEscalas,char escala,int ciclo){
    for(int i=0;i<cantEscalas;i++)
        if(arrEscalas[i].escala==escala and arrEscalas[i].semestre==ciclo) return i;
    return NO_ENCONTRADO;
}

void ordenarDatos(struct Curso *arrCursos,int cantCursos){
    for(int i=0;i<cantCursos-1;i++){
        for(int j=i+1;j<cantCursos;j++){
            if(arrCursos[i].codigo>arrCursos[j].codigo)
                cambiarCursos(arrCursos[i],arrCursos[j]);
        }
    }
    for(int i=0;i<cantCursos;i++){
        ordenarAlumnos(arrCursos[i].alumnos,arrCursos[i].cantMatriculados);
    }
}

void cambiarCursos(struct Curso &cursoI, struct Curso &cursoJ){
    struct Curso aux = cursoI;
    cursoI=cursoJ;
    cursoJ=aux;
}

void ordenarAlumnos(struct Alumno *arrAlumnos,int cantAlumnos){
    //como no especifican cómo ordenar los alumnos, me guié del ejemplo y lo hice de forma descendente
    for(int i=0;i<cantAlumnos-1;i++)
        for(int j=i+1;j<cantAlumnos;j++)
            if(arrAlumnos[i].codigo<arrAlumnos[j].codigo)
                cambiarAlumnos(arrAlumnos[i],arrAlumnos[j]);
}

void cambiarAlumnos(struct Alumno &alumnoI, struct Alumno &alumnoJ){
    struct Alumno aux = alumnoI;
    alumnoI=alumnoJ;
    alumnoJ=aux;
}

void emitirReporte(const struct Curso *arrCursos,int cantCursos, int ciclo){
    double totalPago=0;
    ofstream archReporte("ReporteDePagoPorCurso.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"Error en la apertura del archivo ReporteDePagoPorCurso.txt"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2)<<fixed;
    archReporte<<setw(71)<<"INSTITUCION EDUCATIVA_TP"<<endl;
    archReporte<<setw(77)<<"DETALLE DE PAGOS REALIZADO POR CICLO"<<endl;
    archReporte<<setw(59)<<"CICLO: "<<ciclo/10<<'-'<<ciclo%10<<endl;
    imprimirLinea('=',veces,archReporte);
    for(int i=0;i<cantCursos;i++){
        archReporte<<"No."<<setw(11)<<"CURSO"<<setw(63)<<"CREDITOS"<<endl;
        imprimirLinea('-',veces,archReporte);
        archReporte<<setfill('0')<<setw(2)<<i+1<<')'<<setfill(' ')<<setw(3)<<' '<<
                arrCursos[i].codigo<<" - "<<left<<setw(50)<<arrCursos[i].nombre<<right
                <<setprecision(2)<<setw(10)<<arrCursos[i].creditos<<endl;
        imprimirPorAlumno(arrCursos[i].alumnos,arrCursos[i].cantMatriculados,
                arrCursos[i].creditos,archReporte);
        archReporte<<endl;
        archReporte<<"TOTAL DE INGRESOS POR MATRICULA: "<<setprecision(2)<<arrCursos[i].ingresos<<endl;
        imprimirLinea('=',veces,archReporte);
        totalPago+=arrCursos[i].ingresos;
    }
    archReporte<<"MONTO TOTAL POR INGRESOS DE MATRICULA"<<setw(10)<<setprecision(2)<<totalPago<<endl;
    imprimirLinea('=',veces,archReporte);
}

void imprimirPorAlumno(struct Alumno *arrAlumnos,int cantAlumnos, double creditos, ofstream &archReporte){
    archReporte<<setw(26)<<"ALUMNOS MATRICULADOS"<<endl;
    archReporte<<setw(9)<<"No."<<setw(10)<<"ALUMNO"<<setw(57)<<"ESCALA"<<setw(22)<<
            "PAGO POR CREDITO"<<setw(19)<<"TOTAL A PAGAR"<<endl;
    for(int i=0;i<cantAlumnos;i++){
        archReporte<<setw(6)<<' '<<setfill('0')<<setw(2)<<i+1<<')'<<setfill(' ')<<setw(12)<<
                arrAlumnos[i].codigo<<setw(2)<<' '<<left<<setw(50)<<arrAlumnos[i].nombre
                <<setw(4)<<arrAlumnos[i].escala<<right<<setw(15)<<setprecision(2)<<
                arrAlumnos[i].pago<<setw(22)<<setprecision(2)<<arrAlumnos[i].pago*creditos<<endl;
    }
}

void imprimirLinea(char simbolo, int cant, ofstream &archReporte){
    for(int i=0;i<cant;i++)
        archReporte.put(simbolo);
    archReporte<<endl;
}