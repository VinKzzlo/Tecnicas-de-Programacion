/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Escala.h

 *
 * Created on 13 de noviembre de 2023, 07:06 PM
 */

#ifndef ESCALA_H
#define ESCALA_H

struct Escala{
    int semestre;
    char escala;
    double valorCredito;
};

#endif /* ESCALA_H */

