/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * Archivo:   main.cpp
 * Autor: VinKzzlo
 *
 * Creado el on 26 de abril de 2024, 21:26
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "FuncionesParaReporte.h"
/*
 * 
 */
int main(int argc, char** argv) {

    emitirReporte("CitasMedicas.txt", "Medicos.txt", "ReporteDeCitas.txt");
    
    return 0;
}

